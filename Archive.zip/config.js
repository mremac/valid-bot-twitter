var config = {
  consumer_key:         'dGU3KLOCgdKCC7poSEFf97y9S',
  consumer_secret:      'BBuHCkmt0RXbdLb5UdjgjTqKseEvUsh7crtG7McqlDh99ec0tN',
  access_token:         '1079435515596812290-5AEVoei1hQTEmJKhrEDQYWxjGXOsFJ',
  access_token_secret:  'hZ0rzYGK6Fa1ThBOI7h4SKloRCNFP3DznPoYnXQa9JrEF'
}

module.exports = config;